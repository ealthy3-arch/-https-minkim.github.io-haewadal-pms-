# 해와달 모텔 PMS — C# 네이티브 v7.3 빌드 가이드

## 요구사항
- Windows 10/11 64-bit
- .NET 8 SDK (https://dotnet.microsoft.com/download)
  → "SDK 8.0.x" 설치 (Runtime 아님)
- Python 불필요 — 완전 독립 실행

---

## 빌드 방법

### 1) 개발용 실행 (디버그)
```cmd
cd HaewadalMotel
dotnet run
```

### 2) 배포용 단일 EXE 생성
```cmd
cd HaewadalMotel
dotnet publish -c Release -r win-x64 --self-contained
```
결과물: `bin\Release\net8.0-windows\win-x64\publish\해와달모텔PMS.exe`

→ 이 EXE 파일 하나만 복사하면 어디서든 실행됩니다.

---

## 데이터 저장 위치
`C:\Users\사용자명\AppData\Roaming\HaeWaDalPMS\motel_native.db`

---

## v7.3 기능 목록

### P0 — 인증
- 최초 실행 시 관리자 계정 자동 생성 안내
- SHA-256 PIN 인증 (4자리 이상)
- 로그인 폼 → 메인 폼 전환

### P1 — 업무 기능
| 기능 | 설명 |
|------|------|
| 체크인 | 고객명/전화/예상체크아웃/요금 입력 |
| 체크아웃 | 이력 자동 저장, 이력 ID 표시 |
| 노쇼 처리 | 위약금 금액 입력, noshow 유형 기록 |
| 환불 | 이력 ID + 금액 입력, 초과 환불 방지 |
| 객실 상태 | 이용가능/청소중/점검중/고장 변경 |
| 전화번호 마스킹 | 010-****-5678 형식으로 표시 |
| 일마감 정산 | 날짜별 체크인/아웃/매출/환불 집계 |
| CSV 내보내기 | 홈 디렉터리에 UTF-8 BOM CSV 저장 |

### P2 — 운영/컴플라이언스
| 기능 | 설명 |
|------|------|
| 스키마 마이그레이션 | v1→v2→v3 자동 업그레이드 |
| RBAC 3등급 | admin / counter / cleaning 역할 분리 |
| 접근 로그 | 로그인/로그아웃/작업 기록 (access_log) |
| 개인정보 보관 정책 | 기본 365일, 최소 30일, UI에서 변경 |
| 자동 익명화 | 보관 기간 초과 이력 → [익명] 처리 |

---

## 역할별 허용 작업
| 작업 | admin | counter | cleaning |
|------|:-----:|:-------:|:--------:|
| 체크인/아웃/노쇼/환불 | ✅ | ✅ | ❌ |
| 청소·이용가능 변경 | ✅ | ✅ | ✅ |
| 점검·고장 변경 | ✅ | ❌ | ❌ |
| 일마감·CSV | ✅ | ✅ | ❌ |
| 직원 관리 | ✅ | ❌ | ❌ |
| 개인정보 익명화 | ✅ | ❌ | ❌ |

---

## Python 버전 vs C# 버전 비교
| 항목 | Python v7.3 | C# v7.3 |
|------|------------|---------|
| 실행 | Python 설치 필요 | EXE 단독 실행 |
| 배포 크기 | ~14MB (PyInstaller) | ~30MB (self-contained) |
| 성능 | 보통 | 빠름 |
| 테스트 | pytest 75건 | 추후 xUnit 추가 예정 |
| DB | SQLite (동일) | SQLite (동일) |
| 코드 줄 수 | 937줄 | 983줄 |
