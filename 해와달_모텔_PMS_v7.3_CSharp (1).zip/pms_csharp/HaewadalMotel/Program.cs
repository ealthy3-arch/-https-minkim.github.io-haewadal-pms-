// 해와달 모텔 PMS — C# WinForms 네이티브 v7.3
// Python 없이 실행 | .NET 8 + Microsoft.Data.Sqlite
// P0: 인증·RBAC | P1: 노쇼·환불·일마감·마스킹·점검/고장 | P2: 마이그레이션·익명화

using System.Data;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;

namespace HaewadalMotel;

// ═══════════════════════════════════════════════════════════════════════════
// 진입점
// ═══════════════════════════════════════════════════════════════════════════
internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        var dbPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "HaeWaDalPMS", "motel_native.db");
        Directory.CreateDirectory(Path.GetDirectoryName(dbPath)!);

        var repo = new MotelRepository(dbPath);
        Application.Run(new LoginForm(repo));
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 상수 / 열거형
// ═══════════════════════════════════════════════════════════════════════════
public enum RoomStatus { Available, Occupied, Cleaning, Inspection, Broken }
public enum CheckoutType { Normal, Noshow, Refund }
public enum StaffRole { Admin, Counter, Cleaning }

public static class Permissions
{
    private static readonly Dictionary<StaffRole, HashSet<string>> _map = new()
    {
        [StaffRole.Admin] = new()
        {
            "checkin","checkout","noshow","refund",
            "set_cleaning","set_inspection","set_broken","set_available",
            "daily_report","export_csv","anonymize","manage_users"
        },
        [StaffRole.Counter] = new()
        {
            "checkin","checkout","noshow","refund",
            "set_cleaning","set_available","daily_report","export_csv"
        },
        [StaffRole.Cleaning] = new()
        {
            "set_cleaning","set_available"
        },
    };

    public static bool Can(StaffRole role, string action) =>
        _map.TryGetValue(role, out var set) && set.Contains(action);
}

// ═══════════════════════════════════════════════════════════════════════════
// 모델
// ═══════════════════════════════════════════════════════════════════════════
public record StaffAccount(int Id, string Username, StaffRole Role, bool IsActive, string CreatedAt);

public record StayRecord(
    int Id, string RoomNumber, string GuestName, string GuestPhone,
    string CheckinAt, string CheckoutAt, int FinalPrice, int RefundAmount,
    CheckoutType Type, string CreatedAt)
{
    public int NetRevenue => FinalPrice - RefundAmount;
}

public record DailyReport(
    string Date,
    int TotalCheckins, int TotalCheckouts,
    int NormalCount, int NoshowCount, int RefundCount,
    int GrossRevenue, int TotalRefunds, int NetRevenue,
    List<DailyLineItem> Breakdown);

public record DailyLineItem(
    int Id, string RoomNumber, string GuestName, string GuestPhone,
    int FinalPrice, int RefundAmount, int Net,
    string Type, string CheckoutAt);

public static class PhoneMask
{
    public static string Mask(string phone)
    {
        if (string.IsNullOrEmpty(phone)) return "";
        var digits = new string(phone.Where(char.IsDigit).ToArray());
        return digits.Length switch
        {
            11 => $"{digits[..3]}-****-{digits[7..]}",
            10 => $"{digits[..3]}-***-{digits[6..]}",
            >= 4 => $"{new string('*', digits.Length - 4)}{digits[^4..]}",
            _ => "****"
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 레포지토리
// ═══════════════════════════════════════════════════════════════════════════
public sealed class MotelRepository
{
    private readonly string _cs;
    private const int SchemaTarget = 3;
    private const int DefaultRetentionDays = 365;

    public MotelRepository(string dbPath)
    {
        _cs = new SqliteConnectionStringBuilder { DataSource = dbPath }.ToString();
        Migrate();
        SeedIfEmpty();
    }

    // ── 연결 헬퍼 ────────────────────────────────────────────────────────────
    private SqliteConnection Open() { var c = new SqliteConnection(_cs); c.Open(); return c; }
    private static string NowIso() => DateTime.Now.ToString("s");
    private static string TodayIso() => DateTime.Today.ToString("yyyy-MM-dd");
    private static string Sha256(string text)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(text));
        return Convert.ToHexString(bytes).ToLower();
    }

    // ── 마이그레이션 (P2) ────────────────────────────────────────────────────
    public void Migrate()
    {
        using var conn = Open();
        conn.Execute(@"CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY)");
        var current = conn.QueryScalar<long>("SELECT COALESCE(MAX(version),0) FROM schema_version");

        if (current < 1)
        {
            conn.Execute(@"
                CREATE TABLE IF NOT EXISTS rooms (
                    room_number TEXT PRIMARY KEY,
                    room_type   TEXT NOT NULL,
                    status      TEXT NOT NULL DEFAULT 'available',
                    guest_name  TEXT, guest_phone TEXT,
                    checkin_at  TEXT, checkout_at TEXT,
                    price       INTEGER DEFAULT 0,
                    updated_at  TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS stay_history (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    room_number   TEXT    NOT NULL,
                    guest_name    TEXT    NOT NULL,
                    guest_phone   TEXT,
                    checkin_at    TEXT    NOT NULL,
                    checkout_at   TEXT    NOT NULL,
                    final_price   INTEGER NOT NULL DEFAULT 0,
                    refund_amount INTEGER NOT NULL DEFAULT 0,
                    checkout_type TEXT    NOT NULL DEFAULT 'normal',
                    anonymized    INTEGER NOT NULL DEFAULT 0,
                    created_at    TEXT    NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_co ON stay_history (substr(checkout_at,1,10));
                INSERT INTO schema_version VALUES (1);
            ");
        }
        if (current < 2)
        {
            conn.Execute(@"
                CREATE TABLE IF NOT EXISTS staff (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    username   TEXT UNIQUE NOT NULL,
                    pin_hash   TEXT NOT NULL,
                    role       TEXT NOT NULL DEFAULT 'counter',
                    is_active  INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS access_log (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    username  TEXT NOT NULL,
                    role      TEXT NOT NULL,
                    event     TEXT NOT NULL,
                    logged_at TEXT NOT NULL
                );
                INSERT INTO schema_version VALUES (2);
            ");
        }
        if (current < 3)
        {
            try { conn.Execute("ALTER TABLE stay_history ADD COLUMN anonymized INTEGER NOT NULL DEFAULT 0"); }
            catch (SqliteException) { /* 이미 존재 */ }
            conn.Execute($@"
                CREATE TABLE IF NOT EXISTS privacy_policy (
                    id INTEGER PRIMARY KEY, retention_days INTEGER NOT NULL DEFAULT {DefaultRetentionDays}, updated_at TEXT NOT NULL
                );
                INSERT OR IGNORE INTO privacy_policy (id, retention_days, updated_at) VALUES (1, {DefaultRetentionDays}, '{NowIso()}');
                INSERT INTO schema_version VALUES (3);
            ");
        }
    }

    public int SchemaVersion()
    {
        using var conn = Open();
        return (int)conn.QueryScalar<long>("SELECT COALESCE(MAX(version),0) FROM schema_version");
    }

    // ── 시드 ────────────────────────────────────────────────────────────────
    private void SeedIfEmpty()
    {
        using var conn = Open();
        if (conn.QueryScalar<long>("SELECT COUNT(*) FROM rooms") > 0) return;
        var types = new[] { "standard", "ondol", "twin", "couple", "longterm" };
        var now = NowIso();
        for (var fl = 1; fl <= 3; fl++)
            for (var i = 1; i <= 10; i++)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO rooms (room_number,room_type,status,updated_at) VALUES ($n,$t,'available',$u)";
                cmd.Parameters.AddWithValue("$n", $"{fl}{i:00}");
                cmd.Parameters.AddWithValue("$t", types[(i - 1) % types.Length]);
                cmd.Parameters.AddWithValue("$u", now);
                cmd.ExecuteNonQuery();
            }
    }

    // ── 인증 / RBAC ──────────────────────────────────────────────────────────
    public bool HasAnyAdmin()
    {
        using var conn = Open();
        return conn.QueryScalar<long>("SELECT COUNT(*) FROM staff WHERE role='admin' AND is_active=1") > 0;
    }

    public StaffAccount? Login(string username, string pin)
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT id,username,role,is_active,created_at FROM staff WHERE username=$u AND pin_hash=$p AND is_active=1";
        cmd.Parameters.AddWithValue("$u", username.Trim());
        cmd.Parameters.AddWithValue("$p", Sha256(pin));
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return null;
        var acc = new StaffAccount(r.GetInt32(0), r.GetString(1),
            Enum.Parse<StaffRole>(r.GetString(2), true), r.GetInt32(3) == 1, r.GetString(4));
        LogAccess(conn, acc, "login");
        return acc;
    }

    public void Logout(StaffAccount acc) { using var conn = Open(); LogAccess(conn, acc, "logout"); }

    public void CreateStaff(string username, string pin, StaffRole role)
    {
        if (pin.Length < 4) throw new ArgumentException("PIN은 4자리 이상");
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "INSERT INTO staff (username,pin_hash,role,is_active,created_at) VALUES ($u,$p,$r,1,$c)";
        cmd.Parameters.AddWithValue("$u", username.Trim());
        cmd.Parameters.AddWithValue("$p", Sha256(pin));
        cmd.Parameters.AddWithValue("$r", role.ToString().ToLower());
        cmd.Parameters.AddWithValue("$c", NowIso());
        cmd.ExecuteNonQuery();
    }

    public void DeactivateStaff(string username)
    {
        using var conn = Open();
        conn.Execute($"UPDATE staff SET is_active=0 WHERE username='{username.Replace("'", "''")}' ");
    }

    public List<StaffAccount> ListStaff()
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT id,username,role,is_active,created_at FROM staff ORDER BY role,username";
        using var r = cmd.ExecuteReader();
        var list = new List<StaffAccount>();
        while (r.Read())
            list.Add(new(r.GetInt32(0), r.GetString(1),
                Enum.Parse<StaffRole>(r.GetString(2), true), r.GetInt32(3) == 1, r.GetString(4)));
        return list;
    }

    public void LogAction(StaffAccount acc, string action, string detail = "")
    {
        using var conn = Open();
        LogAccess(conn, acc, $"{action}:{detail}");
    }

    private static void LogAccess(SqliteConnection conn, StaffAccount acc, string ev)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "INSERT INTO access_log (username,role,event,logged_at) VALUES ($u,$r,$e,$t)";
        cmd.Parameters.AddWithValue("$u", acc.Username);
        cmd.Parameters.AddWithValue("$r", acc.Role.ToString().ToLower());
        cmd.Parameters.AddWithValue("$e", ev);
        cmd.Parameters.AddWithValue("$t", NowIso());
        cmd.ExecuteNonQuery();
    }

    public List<Dictionary<string, string>> AccessLog(int limit = 200)
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT username,role,event,logged_at FROM access_log ORDER BY logged_at DESC LIMIT $l";
        cmd.Parameters.AddWithValue("$l", limit);
        using var r = cmd.ExecuteReader();
        var list = new List<Dictionary<string, string>>();
        while (r.Read())
            list.Add(new() { ["username"] = r.GetString(0), ["role"] = r.GetString(1),
                              ["event"] = r.GetString(2),   ["logged_at"] = r.GetString(3) });
        return list;
    }

    // ── 객실 목록 ────────────────────────────────────────────────────────────
    public DataTable ListRooms()
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            SELECT room_number AS '객실번호', room_type AS '유형',
                   CASE status
                       WHEN 'available'  THEN '이용가능'
                       WHEN 'occupied'   THEN '사용중'
                       WHEN 'cleaning'   THEN '청소중'
                       WHEN 'inspection' THEN '점검중'
                       WHEN 'broken'     THEN '고장'
                       ELSE status END AS '상태',
                   COALESCE(guest_name,'')  AS '고객명',
                   COALESCE(masked_phone(guest_phone),'') AS '전화(마스킹)',
                   COALESCE(checkin_at,'')  AS '체크인',
                   COALESCE(checkout_at,'') AS '체크아웃예정',
                   COALESCE(price,0)        AS '요금',
                   room_number              AS _raw_room_number
            FROM rooms ORDER BY room_number";
        // 마스킹은 C# 측에서 처리
        using var cmd2 = conn.CreateCommand();
        cmd2.CommandText = @"
            SELECT room_number, room_type,
                   CASE status
                       WHEN 'available'  THEN '이용가능'
                       WHEN 'occupied'   THEN '사용중'
                       WHEN 'cleaning'   THEN '청소중'
                       WHEN 'inspection' THEN '점검중'
                       WHEN 'broken'     THEN '고장'
                       ELSE status END AS status_kr,
                   COALESCE(guest_name,'')  AS guest_name,
                   COALESCE(guest_phone,'') AS guest_phone,
                   COALESCE(checkin_at,'')  AS checkin_at,
                   COALESCE(checkout_at,'') AS checkout_at,
                   COALESCE(price,0)        AS price
            FROM rooms ORDER BY room_number";
        using var reader = cmd2.ExecuteReader();
        var table = new DataTable();
        table.Columns.Add("객실번호"); table.Columns.Add("유형");
        table.Columns.Add("상태");    table.Columns.Add("고객명");
        table.Columns.Add("전화(마스킹)"); table.Columns.Add("체크인");
        table.Columns.Add("체크아웃예정"); table.Columns.Add("요금");
        while (reader.Read())
            table.Rows.Add(
                reader.GetString(0), reader.GetString(1), reader.GetString(2),
                reader.GetString(3), PhoneMask.Mask(reader.GetString(4)),
                reader.GetString(5), reader.GetString(6),
                $"{reader.GetInt32(7):N0}");
        return table;
    }

    // ── 체크인 ───────────────────────────────────────────────────────────────
    public void CheckIn(string roomNo, string name, string phone, string expectedCheckout, int price)
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"UPDATE rooms SET status='occupied',guest_name=$name,guest_phone=$phone,
            checkin_at=$ci,checkout_at=$co,price=$price,updated_at=$up WHERE room_number=$room";
        var now = NowIso();
        cmd.Parameters.AddWithValue("$name", name);
        cmd.Parameters.AddWithValue("$phone", phone);
        cmd.Parameters.AddWithValue("$ci", now);
        cmd.Parameters.AddWithValue("$co", expectedCheckout);
        cmd.Parameters.AddWithValue("$price", price);
        cmd.Parameters.AddWithValue("$up", now);
        cmd.Parameters.AddWithValue("$room", roomNo);
        cmd.ExecuteNonQuery();
    }

    // ── 체크아웃 (공통) ──────────────────────────────────────────────────────
    private StayRecord? DoCheckout(string roomNo, CheckoutType type, int? overridePrice = null)
    {
        using var conn = Open();
        using var tx = conn.BeginTransaction();
        try
        {
            using var roomCmd = conn.CreateCommand();
            roomCmd.Transaction = tx;
            roomCmd.CommandText = "SELECT guest_name,guest_phone,checkin_at,price,status FROM rooms WHERE room_number=$r";
            roomCmd.Parameters.AddWithValue("$r", roomNo);
            using var rr = roomCmd.ExecuteReader();
            if (!rr.Read() || rr.GetString(4) != "occupied") return null;

            var guestName  = rr.IsDBNull(0) ? "-" : rr.GetString(0);
            var guestPhone = rr.IsDBNull(1) ? "" : rr.GetString(1);
            var checkin    = rr.IsDBNull(2) ? NowIso() : rr.GetString(2);
            var price      = overridePrice ?? (rr.IsDBNull(3) ? 0 : rr.GetInt32(3));
            rr.Close();

            var now = NowIso();
            using var histCmd = conn.CreateCommand();
            histCmd.Transaction = tx;
            histCmd.CommandText = @"INSERT INTO stay_history
                (room_number,guest_name,guest_phone,checkin_at,checkout_at,
                 final_price,refund_amount,checkout_type,anonymized,created_at)
                VALUES ($rn,$gn,$gp,$ci,$co,$fp,0,$ct,0,$cr)";
            histCmd.Parameters.AddWithValue("$rn", roomNo);
            histCmd.Parameters.AddWithValue("$gn", guestName);
            histCmd.Parameters.AddWithValue("$gp", guestPhone);
            histCmd.Parameters.AddWithValue("$ci", checkin);
            histCmd.Parameters.AddWithValue("$co", now);
            histCmd.Parameters.AddWithValue("$fp", price);
            histCmd.Parameters.AddWithValue("$ct", type.ToString().ToLower());
            histCmd.Parameters.AddWithValue("$cr", now);
            var stayId = (int)histCmd.ExecuteScalar2(conn, tx);

            using var upCmd = conn.CreateCommand();
            upCmd.Transaction = tx;
            upCmd.CommandText = @"UPDATE rooms SET status='available',guest_name=NULL,guest_phone=NULL,
                checkin_at=NULL,checkout_at=NULL,price=0,updated_at=$up WHERE room_number=$r";
            upCmd.Parameters.AddWithValue("$up", now);
            upCmd.Parameters.AddWithValue("$r", roomNo);
            upCmd.ExecuteNonQuery();

            tx.Commit();
            return new StayRecord(stayId, roomNo, guestName, guestPhone, checkin, now, price, 0, type, now);
        }
        catch { tx.Rollback(); throw; }
    }

    public StayRecord? CheckOut(string roomNo)        => DoCheckout(roomNo, CheckoutType.Normal);
    public StayRecord? CheckOutNoshow(string roomNo, int penalty) => DoCheckout(roomNo, CheckoutType.Noshow, penalty);

    // ── 환불 ─────────────────────────────────────────────────────────────────
    public bool Refund(int stayId, int amount)
    {
        using var conn = Open();
        using var checkCmd = conn.CreateCommand();
        checkCmd.CommandText = "SELECT final_price,refund_amount FROM stay_history WHERE id=$id";
        checkCmd.Parameters.AddWithValue("$id", stayId);
        using var r = checkCmd.ExecuteReader();
        if (!r.Read()) return false;
        var maxRefund = r.GetInt32(0) - r.GetInt32(1);
        r.Close();
        if (amount > maxRefund)
            throw new InvalidOperationException($"환불 금액({amount:N0}원)이 잔여 결제액({maxRefund:N0}원)을 초과합니다.");
        using var upCmd = conn.CreateCommand();
        upCmd.CommandText = "UPDATE stay_history SET refund_amount=refund_amount+$amt,checkout_type='refund' WHERE id=$id";
        upCmd.Parameters.AddWithValue("$amt", amount);
        upCmd.Parameters.AddWithValue("$id", stayId);
        upCmd.ExecuteNonQuery();
        return true;
    }

    // ── 상태 변경 ────────────────────────────────────────────────────────────
    public void UpdateStatus(string roomNo, RoomStatus status)
    {
        var s = status switch
        {
            RoomStatus.Available  => "available",
            RoomStatus.Occupied   => "occupied",
            RoomStatus.Cleaning   => "cleaning",
            RoomStatus.Inspection => "inspection",
            RoomStatus.Broken     => "broken",
            _ => throw new ArgumentOutOfRangeException()
        };
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE rooms SET status=$s,updated_at=$u WHERE room_number=$r";
        cmd.Parameters.AddWithValue("$s", s);
        cmd.Parameters.AddWithValue("$u", NowIso());
        cmd.Parameters.AddWithValue("$r", roomNo);
        cmd.ExecuteNonQuery();
    }

    // ── 통계 ─────────────────────────────────────────────────────────────────
    public (int Available, int Occupied, int Cleaning, int Inspection, int Broken, int TodayRevenue) GetStats()
    {
        using var conn = Open();
        int Count(string v)
        {
            using var c = conn.CreateCommand();
            c.CommandText = "SELECT COUNT(*) FROM rooms WHERE status=$s";
            c.Parameters.AddWithValue("$s", v);
            return (int)c.ExecuteScalar<long>();
        }
        using var revCmd = conn.CreateCommand();
        revCmd.CommandText = "SELECT COALESCE(SUM(final_price-refund_amount),0) FROM stay_history WHERE substr(checkout_at,1,10)=$t";
        revCmd.Parameters.AddWithValue("$t", TodayIso());
        var rev = (int)revCmd.ExecuteScalar<long>();
        return (Count("available"), Count("occupied"), Count("cleaning"), Count("inspection"), Count("broken"), rev);
    }

    // ── 일마감 정산 ──────────────────────────────────────────────────────────
    public DailyReport GetDailyReport(string? reportDate = null)
    {
        var d = reportDate ?? TodayIso();
        using var conn = Open();

        var ciCount = (int)conn.QueryScalar<long>(
            $"SELECT COUNT(*) FROM stay_history WHERE substr(checkin_at,1,10)='{d}'");

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT id,room_number,guest_name,guest_phone,
            checkin_at,checkout_at,final_price,refund_amount,checkout_type
            FROM stay_history WHERE substr(checkout_at,1,10)=$d ORDER BY checkout_at";
        cmd.Parameters.AddWithValue("$d", d);
        using var r = cmd.ExecuteReader();

        int normal = 0, noshow = 0, refundCt = 0, gross = 0, totalRefunds = 0;
        var breakdown = new List<DailyLineItem>();
        while (r.Read())
        {
            var ct = r.GetString(8);
            if (ct == "noshow") noshow++;
            else if (ct == "refund") refundCt++;
            else normal++;
            var fp = r.GetInt32(6); var ra = r.GetInt32(7);
            gross += fp; totalRefunds += ra;
            breakdown.Add(new(r.GetInt32(0), r.GetString(1), r.GetString(2),
                PhoneMask.Mask(r.GetString(3)), fp, ra, fp - ra, ct, r.GetString(5)));
        }
        return new DailyReport(d, ciCount, breakdown.Count, normal, noshow, refundCt,
            gross, totalRefunds, gross - totalRefunds, breakdown);
    }

    public string ExportCsv(string? reportDate = null)
    {
        var rpt = GetDailyReport(reportDate);
        var sb = new StringBuilder();
        sb.AppendLine($"날짜,{rpt.Date}");
        sb.AppendLine($"체크인,{rpt.TotalCheckins},체크아웃,{rpt.TotalCheckouts}");
        sb.AppendLine($"정상,{rpt.NormalCount},노쇼,{rpt.NoshowCount},환불,{rpt.RefundCount}");
        sb.AppendLine($"총매출,{rpt.GrossRevenue},총환불,{rpt.TotalRefunds},순매출,{rpt.NetRevenue}");
        sb.AppendLine();
        sb.AppendLine("객실,고객명,전화(마스킹),결제액,환불액,순액,유형,체크아웃");
        foreach (var b in rpt.Breakdown)
            sb.AppendLine($"{b.RoomNumber},{b.GuestName},{b.GuestPhone},{b.FinalPrice},{b.RefundAmount},{b.Net},{b.Type},{b.CheckoutAt}");
        return sb.ToString();
    }

    // ── 개인정보 익명화 (P2) ────────────────────────────────────────────────
    public int GetRetentionDays()
    {
        using var conn = Open();
        return (int)conn.QueryScalar<long>(
            "SELECT retention_days FROM privacy_policy WHERE id=1");
    }

    public void SetRetentionDays(int days)
    {
        if (days < 30) throw new ArgumentException("보관 기간은 최소 30일");
        using var conn = Open();
        conn.Execute($"UPDATE privacy_policy SET retention_days={days},updated_at='{NowIso()}' WHERE id=1");
    }

    public (int Active, int Anonymized) AnonymizationStats()
    {
        using var conn = Open();
        var active = (int)conn.QueryScalar<long>("SELECT COUNT(*) FROM stay_history WHERE anonymized=0");
        var anon   = (int)conn.QueryScalar<long>("SELECT COUNT(*) FROM stay_history WHERE anonymized=1");
        return (active, anon);
    }

    public int Anonymize(string? beforeDate = null, int? retentionDays = null)
    {
        var days   = retentionDays ?? GetRetentionDays();
        var cutoff = beforeDate ?? DateTime.Today.AddDays(-days).ToString("yyyy-MM-dd");
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"UPDATE stay_history SET guest_name='[익명]',guest_phone='',anonymized=1
            WHERE anonymized=0 AND substr(checkout_at,1,10)<$c";
        cmd.Parameters.AddWithValue("$c", cutoff);
        return cmd.ExecuteNonQuery();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// SQLite 헬퍼 확장
// ═══════════════════════════════════════════════════════════════════════════
public static class SqliteExtensions
{
    public static void Execute(this SqliteConnection conn, string sql)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }

    public static T QueryScalar<T>(this SqliteConnection conn, string sql)
    {
        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        return (T)Convert.ChangeType(cmd.ExecuteScalar()!, typeof(T));
    }

    public static T ExecuteScalar<T>(this SqliteCommand cmd)
        => (T)Convert.ChangeType(cmd.ExecuteScalar()!, typeof(T));

    // LAST_INSERT_ROWID() 별도 쿼리
    public static long ExecuteScalar2(this SqliteCommand cmd,
        SqliteConnection conn, SqliteTransaction tx)
    {
        cmd.ExecuteNonQuery();
        using var rowIdCmd = conn.CreateCommand();
        rowIdCmd.Transaction = tx;
        rowIdCmd.CommandText = "SELECT last_insert_rowid()";
        return (long)rowIdCmd.ExecuteScalar()!;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 로그인 폼
// ═══════════════════════════════════════════════════════════════════════════
public sealed class LoginForm : Form
{
    private readonly MotelRepository _repo;

    public LoginForm(MotelRepository repo)
    {
        _repo = repo;
        Text = "해와달 모텔 PMS — 로그인";
        Width = 380; Height = 220;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterScreen;
        MaximizeBox = false;

        var lbl = new Label { Text = "아이디", Left = 20, Top = 20, Width = 320 };
        var unBox = new TextBox { Left = 20, Top = 42, Width = 320 };
        var lbl2 = new Label { Text = "PIN", Left = 20, Top = 72, Width = 320 };
        var pinBox = new TextBox { Left = 20, Top = 94, Width = 320, UseSystemPasswordChar = true };
        var loginBtn = new Button { Text = "로그인", Left = 220, Top = 130, Width = 120, Height = 34 };

        loginBtn.Click += (_, _) => TryLogin(unBox.Text, pinBox.Text);
        Controls.AddRange(new Control[] { lbl, unBox, lbl2, pinBox, loginBtn });
        AcceptButton = loginBtn;

        Shown += (_, _) =>
        {
            if (!repo.HasAnyAdmin())
            {
                MessageBox.Show("최초 실행입니다. 관리자 계정을 생성해 주세요.", "최초 설정");
                CreateFirstAdmin();
            }
        };
    }

    private void CreateFirstAdmin()
    {
        while (true)
        {
            var un  = Prompt.Show("관리자 아이디", "관리자 계정 생성") ?? "";
            var pin = Prompt.ShowPassword("PIN (4자리 이상)", "관리자 계정 생성") ?? "";
            if (string.IsNullOrWhiteSpace(un) || pin.Length < 4)
            {
                if (MessageBox.Show("취소하면 앱이 종료됩니다.", "확인",
                    MessageBoxButtons.YesNo) == DialogResult.Yes) { Application.Exit(); return; }
                continue;
            }
            try { _repo.CreateStaff(un, pin, StaffRole.Admin); MessageBox.Show($"관리자 '{un}' 생성 완료"); break; }
            catch (Exception ex) { MessageBox.Show(ex.Message, "오류"); }
        }
    }

    private void TryLogin(string username, string pin)
    {
        var acc = _repo.Login(username, pin);
        if (acc == null) { MessageBox.Show("아이디 또는 PIN이 올바르지 않습니다.", "인증 실패"); return; }
        Hide();
        new MainForm(_repo, acc).ShowDialog();
        Show();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 메인 폼
// ═══════════════════════════════════════════════════════════════════════════
public sealed class MainForm : Form
{
    private readonly MotelRepository _repo;
    private readonly StaffAccount _user;
    private readonly DataGridView _grid;
    private readonly Label _stats;

    public MainForm(MotelRepository repo, StaffAccount user)
    {
        _repo = repo; _user = user;
        Text = $"해와달 모텔 PMS v7.3  |  {user.Username} ({user.Role})";
        Width = 1180; Height = 720;

        // ── 상단 버튼바 ───────────────────────────────────────────────────
        var topPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 52, Padding = new Padding(10) };

        void AddBtn(string label, EventHandler handler)
        {
            var b = new Button { Text = label, Width = 100, Height = 34 };
            b.Click += handler;
            topPanel.Controls.Add(b);
        }

        AddBtn("새로고침",      (_, _) => RefreshData());
        AddBtn("체크인",        (_, _) => Guard("checkin",      DoCheckin));
        AddBtn("체크아웃",      (_, _) => Guard("checkout",     () => DoCheckout(false)));
        AddBtn("노쇼",          (_, _) => Guard("noshow",       DoNoshow));
        AddBtn("환불",          (_, _) => Guard("refund",       DoRefund));
        AddBtn("청소중",        (_, _) => Guard("set_cleaning",  () => SetStatus(RoomStatus.Cleaning)));
        AddBtn("점검중",        (_, _) => Guard("set_inspection",() => SetStatus(RoomStatus.Inspection)));
        AddBtn("고장",          (_, _) => Guard("set_broken",   () => SetStatus(RoomStatus.Broken)));
        AddBtn("이용가능",      (_, _) => Guard("set_available",() => SetStatus(RoomStatus.Available)));
        AddBtn("일마감",        (_, _) => Guard("daily_report", ShowDailyReport));
        AddBtn("직원 관리",     (_, _) => Guard("manage_users", ShowStaffManager));
        AddBtn("개인정보",      (_, _) => Guard("anonymize",    ShowPrivacyPanel));

        _stats = new Label { Dock = DockStyle.Top, Height = 28, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(12, 0, 0, 0) };

        _grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true,
            AutoGenerateColumns = true,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        };

        Controls.Add(_grid); Controls.Add(_stats); Controls.Add(topPanel);
        FormClosed += (_, _) => _repo.Logout(_user);
        RefreshData();
    }

    private void Guard(string action, Action fn)
    {
        if (!Permissions.Can(_user.Role, action))
        { MessageBox.Show($"'{_user.Role}' 역할은 '{action}' 권한이 없습니다.", "권한 없음"); return; }
        fn();
    }

    private string? SelectedRoom() =>
        _grid.CurrentRow?.DataBoundItem is DataRowView row ? row["객실번호"]?.ToString() : null;

    private void RefreshData()
    {
        _grid.DataSource = _repo.ListRooms();
        var s = _repo.GetStats();
        _stats.Text = $"이용가능 {s.Available} | 사용중 {s.Occupied} | 청소중 {s.Cleaning} " +
                      $"| 점검중 {s.Inspection} | 고장 {s.Broken}  |  오늘 순매출 {s.TodayRevenue:N0}원";
    }

    // ── 작업 핸들러 ───────────────────────────────────────────────────────────
    private void DoCheckin()
    {
        var rn = SelectedRoom(); if (rn == null) { MessageBox.Show("객실 선택 필요"); return; }
        var name = Prompt.Show("고객명", "체크인"); if (string.IsNullOrWhiteSpace(name)) return;
        var phone    = Prompt.Show("전화번호", "체크인") ?? "";
        var checkout = Prompt.Show("예상 체크아웃 (예: 2026-06-01 12:00)", "체크인") ?? "";
        var pStr     = Prompt.Show("요금(숫자)", "체크인") ?? "0";
        if (!int.TryParse(pStr, out var price) || price < 0) { MessageBox.Show("유효한 금액 입력"); return; }
        _repo.CheckIn(rn, name, phone, checkout, price);
        _repo.LogAction(_user, "checkin", $"{rn}/{name}");
        RefreshData();
    }

    private void DoCheckout(bool noshow)
    {
        var rn = SelectedRoom(); if (rn == null) { MessageBox.Show("객실 선택 필요"); return; }
        var rec = _repo.CheckOut(rn);
        if (rec != null)
        {
            _repo.LogAction(_user, "checkout", $"{rn}/#{rec.Id}/{rec.FinalPrice:N0}원");
            MessageBox.Show($"체크아웃 완료\n객실 {rn}  고객: {rec.GuestName}\n결제액: {rec.FinalPrice:N0}원\nID: #{rec.Id}");
        }
        RefreshData();
    }

    private void DoNoshow()
    {
        var rn = SelectedRoom(); if (rn == null) { MessageBox.Show("객실 선택 필요"); return; }
        var pStr = Prompt.Show("위약금 금액 (없으면 0)", "노쇼 처리") ?? "0";
        int.TryParse(pStr, out var penalty);
        var rec = _repo.CheckOutNoshow(rn, penalty);
        if (rec != null)
        {
            _repo.LogAction(_user, "noshow", $"{rn}/위약금:{penalty:N0}원");
            MessageBox.Show($"노쇼 처리 완료\n객실 {rn}  위약금: {rec.FinalPrice:N0}원  ID: #{rec.Id}");
        }
        else MessageBox.Show("체크인 상태가 아닙니다.");
        RefreshData();
    }

    private void DoRefund()
    {
        var sidStr = Prompt.Show("이력 ID", "환불");
        if (!int.TryParse(sidStr, out var sid)) { MessageBox.Show("숫자 ID 입력"); return; }
        var amtStr = Prompt.Show("환불 금액", "환불");
        if (!int.TryParse(amtStr, out var amt)) { MessageBox.Show("숫자 입력"); return; }
        try
        {
            if (_repo.Refund(sid, amt))
            {
                _repo.LogAction(_user, "refund", $"#{sid}/{amt:N0}원");
                MessageBox.Show($"이력 #{sid}에 {amt:N0}원 환불 완료");
            }
            else MessageBox.Show("해당 ID를 찾을 수 없습니다.");
        }
        catch (InvalidOperationException ex) { MessageBox.Show(ex.Message, "환불 오류"); }
    }

    private void SetStatus(RoomStatus status)
    {
        var rn = SelectedRoom(); if (rn == null) { MessageBox.Show("객실 선택 필요"); return; }
        _repo.UpdateStatus(rn, status);
        _repo.LogAction(_user, $"set_{status.ToString().ToLower()}", rn);
        RefreshData();
    }

    // ── 일마감 정산 ──────────────────────────────────────────────────────────
    private void ShowDailyReport()
    {
        var d = Prompt.Show("날짜 (YYYY-MM-DD, 빈칸=오늘)", "일마감") ?? DateTime.Today.ToString("yyyy-MM-dd");
        if (string.IsNullOrWhiteSpace(d)) d = DateTime.Today.ToString("yyyy-MM-dd");
        var rpt = _repo.GetDailyReport(d);

        using var win = new Form
        {
            Text = $"일마감 정산 — {d}", Width = 880, Height = 540,
            StartPosition = FormStartPosition.CenterParent
        };
        var summary = new Label
        {
            Text = $"날짜: {rpt.Date}   체크인: {rpt.TotalCheckins}건  체크아웃: {rpt.TotalCheckouts}건\n" +
                   $"정상: {rpt.NormalCount}  노쇼: {rpt.NoshowCount}  환불: {rpt.RefundCount}\n" +
                   $"총 매출: {rpt.GrossRevenue:N0}원  |  총 환불: {rpt.TotalRefunds:N0}원  |  순 매출: {rpt.NetRevenue:N0}원",
            Dock = DockStyle.Top, Height = 60, Padding = new Padding(12, 8, 0, 0),
            Font = new Font("맑은 고딕", 10, FontStyle.Bold)
        };
        var grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AutoGenerateColumns = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AllowUserToAddRows = false, AllowUserToDeleteRows = false
        };
        foreach (var (h, n, w) in new[]
        {
            ("객실",60,"RoomNumber"),("고객명",100,"GuestName"),("전화",120,"GuestPhone"),
            ("결제액",90,"FinalPrice"),("환불액",80,"RefundAmount"),("순액",90,"Net"),
            ("유형",70,"Type"),("체크아웃",140,"CheckoutAt")
        })
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn
                { HeaderText = h, Width = w, DataPropertyName = n });
        }
        grid.DataSource = rpt.Breakdown;

        var bottomPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44 };
        var csvBtn = new Button { Text = "📥 CSV 내보내기", Width = 140, Height = 34 };
        csvBtn.Click += (_, _) =>
        {
            if (!Permissions.Can(_user.Role, "export_csv")) { MessageBox.Show("권한 없음"); return; }
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                $"정산_{d}.csv");
            File.WriteAllText(path, _repo.ExportCsv(d), new UTF8Encoding(true));
            MessageBox.Show($"저장됨:\n{path}");
        };
        bottomPanel.Controls.Add(csvBtn);
        win.Controls.AddRange(new Control[] { grid, bottomPanel, summary });
        win.ShowDialog(this);
    }

    // ── 직원 관리 ─────────────────────────────────────────────────────────────
    private void ShowStaffManager()
    {
        using var win = new Form { Text = "직원 계정 관리", Width = 560, Height = 480, StartPosition = FormStartPosition.CenterParent };
        var listBox = new ListBox { Dock = DockStyle.Top, Height = 240 };
        void Refresh() { listBox.Items.Clear(); foreach (var s in _repo.ListStaff())
            listBox.Items.Add($"{(s.IsActive ? "✅" : "❌")} {s.Username,-15} [{s.Role}]"); }
        Refresh();

        var sep = new Label { Text = "──── 새 계정 추가 ────", Dock = DockStyle.Top, Height = 24, TextAlign = ContentAlignment.MiddleCenter };
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };

        var unBox  = new TextBox { Width = 100, PlaceholderText = "아이디" };
        var pinBox = new TextBox { Width = 80, UseSystemPasswordChar = true, PlaceholderText = "PIN" };
        var roleBox = new ComboBox { Width = 100, DropDownStyle = ComboBoxStyle.DropDownList };
        roleBox.Items.AddRange(new object[] { "Admin", "Counter", "Cleaning" });
        roleBox.SelectedIndex = 1;
        var addBtn = new Button { Text = "추가", Width = 70, Height = 30 };
        addBtn.Click += (_, _) =>
        {
            try
            {
                var role = Enum.Parse<StaffRole>(roleBox.Text, true);
                _repo.CreateStaff(unBox.Text, pinBox.Text, role);
                unBox.Clear(); pinBox.Clear(); Refresh();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "오류"); }
        };
        var deactBtn = new Button { Text = "비활성화", Width = 80, Height = 30 };
        deactBtn.Click += (_, _) =>
        {
            var sel = listBox.SelectedItem?.ToString();
            if (sel == null) return;
            var parts = sel.TrimStart('✅', '❌', ' ').Split(' ');
            if (parts.Length > 0) { _repo.DeactivateStaff(parts[0]); Refresh(); }
        };

        row.Controls.AddRange(new Control[] { unBox, pinBox, roleBox, addBtn, deactBtn });
        win.Controls.AddRange(new Control[] { row, sep, listBox });
        win.ShowDialog(this);
    }

    // ── 개인정보 관리 ─────────────────────────────────────────────────────────
    private void ShowPrivacyPanel()
    {
        var stats = _repo.AnonymizationStats();
        var days  = _repo.GetRetentionDays();
        using var win = new Form { Text = "개인정보 보관 관리", Width = 440, Height = 300, StartPosition = FormStartPosition.CenterParent };

        var info = new Label
        {
            Text = $"보존 이력: {stats.Active}건 / 익명화 완료: {stats.Anonymized}건\n현재 정책: 체크아웃 후 {days}일 보관",
            Left = 20, Top = 20, Width = 380, Height = 48
        };
        var daysLabel = new Label { Text = "보관 기간(일):", Left = 20, Top = 80, Width = 100 };
        var daysBox   = new NumericUpDown { Left = 130, Top = 78, Width = 80, Minimum = 30, Maximum = 3650, Value = days };
        var saveBtn   = new Button { Text = "정책 저장", Left = 220, Top = 76, Width = 100, Height = 30 };
        saveBtn.Click += (_, _) =>
        {
            try { _repo.SetRetentionDays((int)daysBox.Value); MessageBox.Show($"{daysBox.Value}일로 설정됨"); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "오류"); }
        };

        var sep   = new Label { Text = "─────────────────────────────", Left = 20, Top = 120, Width = 380 };
        var anonBtn = new Button
        {
            Text = "⚠️ 익명화 지금 실행", Left = 20, Top = 150, Width = 200, Height = 40,
            BackColor = Color.IndianRed, ForeColor = Color.White
        };
        anonBtn.Click += (_, _) =>
        {
            var n = _repo.Anonymize();
            _repo.LogAction(_user, "anonymize", $"{n}건");
            MessageBox.Show($"{n}건 익명화 완료"); win.Close();
        };
        var note = new Label
        {
            Text = "※ 보관 기간 초과 이력의 고객명·전화번호를\n   [익명]으로 대체합니다.",
            Left = 20, Top = 200, Width = 380, ForeColor = Color.Gray
        };
        win.Controls.AddRange(new Control[] { info, daysLabel, daysBox, saveBtn, sep, anonBtn, note });
        win.ShowDialog(this);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 공통 프롬프트 다이얼로그
// ═══════════════════════════════════════════════════════════════════════════
public static class Prompt
{
    public static string? Show(string text, string caption)   => ShowInternal(text, caption, false);
    public static string? ShowPassword(string text, string caption) => ShowInternal(text, caption, true);

    private static string? ShowInternal(string text, string caption, bool password)
    {
        using var form = new Form
        {
            Width = 440, Height = 180, Text = caption,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition = FormStartPosition.CenterParent,
            MinimizeBox = false, MaximizeBox = false
        };
        var lbl   = new Label { Left = 16, Top = 16, Text = text, Width = 390 };
        var input = new TextBox { Left = 16, Top = 42, Width = 390,
            UseSystemPasswordChar = password };
        var ok     = new Button { Text = "확인", Left = 240, Width = 80, Top = 82, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "취소", Left = 328, Width = 78, Top = 82, DialogResult = DialogResult.Cancel };
        form.Controls.AddRange(new Control[] { lbl, input, ok, cancel });
        form.AcceptButton = ok; form.CancelButton = cancel;
        return form.ShowDialog() == DialogResult.OK ? input.Text : null;
    }
}
