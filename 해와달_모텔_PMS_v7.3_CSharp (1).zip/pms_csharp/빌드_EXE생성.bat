@echo off
chcp 65001 > nul
echo.
echo ╔══════════════════════════════════════════╗
echo ║   해와달 모텔 PMS v7.3 — EXE 빌드       ║
echo ╚══════════════════════════════════════════╝
echo.

where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo [오류] .NET 8 SDK가 설치되어 있지 않습니다.
    echo https://dotnet.microsoft.com/download 에서 설치 후 다시 실행하세요.
    pause
    exit /b 1
)

cd /d "%~dp0HaewadalMotel"

echo [1/2] 패키지 복원 중...
dotnet restore

echo [2/2] Release 빌드 중...
dotnet publish -c Release -r win-x64 --self-contained -o ..\dist

if %errorlevel% == 0 (
    echo.
    echo ✅ 빌드 성공!
    echo 실행 파일: %~dp0dist\해와달모텔PMS.exe
    start "" "%~dp0dist"
) else (
    echo.
    echo ❌ 빌드 실패. 오류를 확인하세요.
)
pause
